import {
    IonList,
    IonItem,
    IonLabel,
    IonAvatar,
    IonButton,
    IonItemOptions,
    IonItemOption,
    IonItemSliding,
    IonListHeader,
    IonIcon,
    IonNote,
} from "@ionic/react";
import { pin, share, trash, chevronForward, archive } from "ionicons/icons";

import { proxy, useSnapshot } from "valtio";
import store from "../common/store";

import { useIonRouter } from "@ionic/react";

interface ContainerProps {
    // chats: [];
}

function timestampToTime(timestamp: number) {
    const date = new Date(timestamp);
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    return `${hours}:${minutes}`;
}

const ChatListItem: React.FC<any> = ({ chats, archived, chatClick, removeChat, toggleArchiveChat }) => {
    const lastMessage = (chat: any) => {
        const messArr = Object.values(chat.messages);
        if (messArr.length === 0) {
            return {};
        }
        return messArr[messArr.length - 1];
    };
    const lastMessageDisplay = (mess: any) => {
        if (mess.text) {
            return mess.text.length > 50 ? mess.text.substring(0, 50) + "..." : mess.text;
        } else if (mess.attachments && mess.attachments.length > 0) {
            return mess.attachments[0].name;
        } else return "";
    };
    return (
        <IonList inset={false}>
            {archived && (
                <IonListHeader>
                    <IonLabel>Archived chats</IonLabel>
                </IonListHeader>
            )}
            {chats.map((chat: any) => {
                const lastMess: any = lastMessage(chat);
                return (
                    <IonItemSliding key={chat.chat_id}>
                        <IonItem button={true} onClick={() => chatClick(chat)}>
                            <IonAvatar aria-hidden="true" slot="start">
                                {/* <img alt="" src="https://ionicframework.com/docs/img/demos/avatar.svg" /> */}
                                {/* TODO: add here color based on chat_name */}
                                <div
                                    style={{
                                        display: "flex",
                                        justifyContent: "center",
                                        alignItems: "center",
                                        width: "100%",
                                        height: "100%",
                                        backgroundColor: "var(--ion-color-primary)",
                                    }}
                                >
                                    <span>{chat.chat_name.toUpperCase().slice(0, 2)}</span>
                                </div>
                            </IonAvatar>
                            <IonLabel>
                                {chat.chat_name}
                                <br />
                                <IonNote color="medium" className="ion-text-wrap">
                                    {lastMessageDisplay(lastMess)}
                                    {/* last message substr max 20 symb; */}
                                </IonNote>
                            </IonLabel>
                            <div className="metadata-end-wrapper" slot="end">
                                <IonNote color="medium">
                                    {lastMess.created_at ? timestampToTime(lastMess.created_at) : ""}
                                </IonNote>
                            </div>
                        </IonItem>
                        <IonItemOptions slot="end">
                            <IonItemOption color="danger" onClick={() => removeChat(chat.chat_id)}>
                                <IonIcon slot="icon-only" icon={trash}></IonIcon>
                            </IonItemOption>
                            <IonItemOption
                                color="tertiary"
                                expandable={true}
                                onClick={() => toggleArchiveChat(chat.chat_id, !archived)}
                            >
                                <IonIcon slot="icon-only" icon={archive}></IonIcon>
                            </IonItemOption>
                        </IonItemOptions>
                    </IonItemSliding>
                );
            })}
        </IonList>
    );
};

const ChatsView: React.FC<any> = () => {
    // const chats: any = Object.values(useSnapshot(store.chats));
    const { chats }: any = useSnapshot(store);
    const router = useIonRouter();

    const chatListActive = [];
    const chatListArchived = [];
    for (const chat of Object.values(chats) as any[]) {
        if (chat.removed) continue;
        if (chat.archived) {
            chatListArchived.push(chat);
        } else {
            chatListActive.push(chat);
        }
    }

    const chatClick = (chat: any) => {
        store.chatsControl.setCurrentChat(chat.chat_id);
        router.push(`/home/chat/${chat.chat_id}`);
    };
    const createChat = () => {};
    const removeChat = (chat_id: string) => {
        if (confirm("Are you sure you want to delete this chat?")) {
            store.chatsControl.deleteChat(chat_id);
        }
    };
    const toggleArchiveChat = (chat_id: string, archived: boolean) => {
        store.chatsControl.toggleArchiveChat(chat_id, archived);
    };

    // console.log("component => chats", Object.values(chats));
    return (
        <>
            <ChatListItem
                chats={chatListActive}
                chatClick={chatClick}
                removeChat={removeChat}
                toggleArchiveChat={toggleArchiveChat}
            />
            <ChatListItem
                archived={true}
                chats={chatListArchived}
                chatClick={chatClick}
                removeChat={removeChat}
                toggleArchiveChat={toggleArchiveChat}
            />
            <IonButton expand="full" onClick={() => store.chatsControl.createChat()}>
                new chat
            </IonButton>
            <span> here just the end</span>
        </>
    );
};

export default ChatsView;
