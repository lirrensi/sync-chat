import "./Chat.css";
import {
    IonContent,
    IonHeader,
    IonPage,
    IonTitle,
    IonToolbar,
    IonIcon,
    IonButtons,
    IonTextarea,
    IonBackButton,
    IonFooter,
    IonInput,
    IonButton,
    IonRefresher,
    IonRefresherContent,
    RefresherEventDetail,
    useIonToast,
} from "@ionic/react";
import { useState, createRef, useEffect } from "react";
import { cogOutline, send, attach, close as iconClose } from "ionicons/icons";
import { useIonRouter } from "@ionic/react";

import AutoGrowInput from "../components/AutoGrowInput";

import { promptFileBasic } from "../common/helpers/files";

import { proxy, useSnapshot } from "valtio";
import { store, fileStorage } from "../common/store";

import { DateTime } from "luxon";
import bytes from "bytes";

const Message: React.FC<any> = ({ message }) => {
    const date = (() => {
        const currentDate = DateTime.local().startOf("day");
        const date = DateTime.fromMillis(message.modified_at || message.created_at);
        let dateString = "";
        if (date.hasSame(currentDate, "day")) {
            // If the date is the same day, return time only
            dateString = date.toFormat("HH:mm");
        } else {
            // If the date is different, return date and time
            dateString = date.toFormat("dd LLL yyyy HH:mm");
        }
        if (message.modified_at) {
            return "mod. " + dateString;
        } else {
            return dateString;
        }
    })();

    return (
        <div className="message-container">
            {message.attachments && (
                <div className="attachment-container">
                    {message.attachments.map((attachment: any) => (
                        <Attachment key={attachment.attachment_id} attachment={attachment} />
                    ))}
                </div>
            )}
            {message.text && (
                <div className="entry-message">
                    <div className="entry-message-main-text">{message.text}</div>
                    <div className="entry-message-sub-text">{date}</div>
                </div>
            )}
        </div>
    );
};

const Attachment: React.FC<any> = ({ attachment }) => {
    const [isLoaded, setIsLoaded] = useState(false);
    useEffect(() => {
        fileStorage.checkAttachmentLoaded(attachment).then(loaded => {
            if (!loaded) {
                // fileStorage.loadAttachment(attachment);
            }
            setIsLoaded(loaded);
        });
    }, [attachment]);

    const date = (() => {
        const currentDate = DateTime.local().startOf("day");
        const date = DateTime.fromMillis(attachment.created_at);
        let dateString = "";
        if (date.hasSame(currentDate, "day")) {
            // If the date is the same day, return time only
            dateString = date.toFormat("HH:mm");
        } else {
            // If the date is different, return date and time
            dateString = date.toFormat("dd LLL yyyy HH:mm");
        }
        return dateString;
    })();

    const size = bytes(attachment.size);

    return (
        <div className="entry-attachment">
            <div className="entry-attachment-img">
                <img src="https://ionicframework.com/docs/img/demos/avatar.svg"></img>
            </div>
            <div>
                <div className="entry-message-main-text">
                    {isLoaded ? "+ " : ""}
                    {attachment.name}
                </div>
                <div className="entry-attachment-size">{size}</div>
                <div className="entry-message-sub-text">{date}</div>
            </div>
        </div>
    );
};

const Chat: React.FC<any> = () => {
    const state = useSnapshot(store);
    // const router = useIonRouter();

    const chat = state.chats[state.chatsControl.currentChat];
    const messages = Object.values(chat.messages);

    const contentRef = createRef<HTMLIonContentElement>();
    useEffect(() => {
        contentRef.current?.scrollToBottom(1);
    }, []);

    const [message, setMessage] = useState("");
    const [attachments, setAttachments] = useState([]);
    const [grow, setGrow] = useState(true);

    const sendMessage = async () => {
        if (message.length === 0 && attachments.length === 0) {
            return;
        }
        // scroll before state changes and rerender occur
        contentRef.current?.scrollToBottom(500);

        await store.chatsControl.createMessage({
            chat_id: chat.chat_id,
            text: message,
            attachments: attachments,
        });
        // console.log('messages not => ', )
        setMessage("");
        setAttachments([]);
    };

    const selectFiles = async () => {
        const fileObjs: any = await promptFileBasic();
        console.log("fileObjs", fileObjs);
        setAttachments(fileObjs);
    };
    const removeFile = (attachment_id: string) => {
        setAttachments(attachments.filter((attObj: any) => attObj.attachment.attachment_id !== attachment_id));
    };

    return (
        <IonPage>
            <IonToolbar>
                <IonButtons slot="start">
                    <IonButtons slot="start">
                        <IonBackButton defaultHref="/" />
                    </IonButtons>
                </IonButtons>
                <IonTitle>{chat.chat_name}</IonTitle>
            </IonToolbar>
            <IonContent ref={contentRef}>
                {messages.map((message: any) => (
                    <Message key={message.message_id} message={message} />
                ))}
            </IonContent>
            <IonFooter className="footer-top-level-container">
                <div className="footer-attachments-container">
                    {attachments.map((attObj: any) => (
                        <div className="footer-attachment-entry" key={attObj.attachment.attachment_id}>
                            <div>
                                <div>
                                    {attObj.attachment.name}{" "}
                                    <span style={{ fontSize: "12px", opacity: 0.8 }}>
                                        {bytes(attObj.attachment.size)}
                                    </span>
                                </div>
                            </div>
                            <IonIcon
                                onClick={() => removeFile(attObj.attachment.attachment_id)}
                                className=""
                                slot="icon-only"
                                icon={iconClose}
                            ></IonIcon>
                        </div>
                    ))}
                </div>
                <div className="footer-input-container">
                    <IonTextarea
                        className="footer-input"
                        placeholder="Message..."
                        autoGrow={grow}
                        wrap="soft"
                        value={message}
                        onIonInput={e => {
                            const message = e.target.value;
                            setMessage(message);
                            setGrow(message.length >= 50);
                            // console.log("current message...", message);
                        }}
                    />
                    <div className="footer-right-container">
                        <div className="footer-right-icon-container" onClick={() => selectFiles()}>
                            <IonIcon slot="icon-only" icon={attach}></IonIcon>
                        </div>
                        <div className="footer-right-icon-container" onClick={() => sendMessage()}>
                            <IonIcon className="footer-right-icon" slot="icon-only" icon={send}></IonIcon>
                        </div>
                    </div>
                </div>
            </IonFooter>
        </IonPage>
    );
};

export default Chat;
