export const PEERJS_CONNECTION_PREFIX = "sync-space-";
export const DATABASE_NAME_CHATS = "chats_db";
