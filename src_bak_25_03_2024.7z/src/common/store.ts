import { proxy } from "valtio";
import { subscribeKey } from "valtio/utils";

import { PeerManager } from "./class/PeerManager";
import { DatabaseManager, DATABASE_HANDLES } from "./class/DatabaseManager";
import { KeyManager, generateUUID } from "./helpers/crypto";
import { FileStorage } from "./helpers/files";
import { Chat, Message, Attachment } from "./types";

// store is central controller and all
// have supportive classes but each does only specific things
// data flow: store function => database => return state to store;

const connMgr = new PeerManager();
const dbMgr = new DatabaseManager();
export const fileStorage = new FileStorage(dbMgr);
const keyManager = new KeyManager();

// store is central thing there everything happens;
// data change: change in store => save in db => return state to store => broadcast changes

const PEER_MESSAGES: string[] = [
    // entity/command or type

    // sends own list on nodes to all peers
    "nodes/broadcast",
    // send own chats state
    "chats/push",
    // request for all connected peers to push their chats state
    "chats/request_push",

    // for small files, sending and requesting files is entirely...
    "attach/request_entire",
    "attach/send_entire",

    "attach/request_stream",
    "attach/send_stream",
];

class Store {
    // related to user account, machine links and keys
    auth = {
        user_id: "",
        machine_id: "",
        known_nodes: {},
        private_key: "",
        keyPassword: "",

        async createNewId(password: string, storePassword = true) {
            console.log("creating new  id");

            this.user_id = generateUUID();
            this.machine_id = generateUUID();
            this.known_nodes = {
                [this.machine_id]: {
                    machine_id: this.machine_id,
                    active: true,
                    device_name: window.navigator.userAgent || "",
                    last_update: Date.now(),
                },
            };

            console.log("creating a new key");
            this.keyPassword = password;
            await keyManager.generateKey();

            if (storePassword) {
                localStorage.setItem("key-password", password);
            }

            console.log("AuthManager done, now saving state...", this);
            await this.saveState();
        },
        async exportCredentials() {
            const keyPass = this.getKeyPassword();
            const exportData = {
                user_id: this.user_id,
                known_nodes: this.known_nodes,
                private_key: await keyManager.exportKeyString(keyPass),
            };
            return JSON.stringify(exportData);
        },
        async importCredentials(exportData: any, storePassword = true) {
            // validate
            if (!exportData.user_id || !exportData.private_key || !exportData.known_nodes) {
                return false;
            }
            const password = prompt("Enter password for private key");
            if (!password) {
                return false;
            }
            this.user_id = exportData.user_id;
            this.machine_id = generateUUID();
            this.known_nodes = exportData.known_nodes;
            this.known_nodes[this.machine_id] = {
                machine_id: this.machine_id,
                active: true,
                device_name: window.navigator.userAgent || "",
                last_update: Date.now(),
            };
            this.keyPassword = password;
            // TODO: add here errors of key decrypt;
            await keyManager.importKeyString(exportData.private_key, password);
            if (storePassword) {
                localStorage.setItem("key-password", password);
            }
            await this.saveState();
            return true;
        },

        getKeyPassword() {
            if (!this.keyPassword) {
                const savedPassword = localStorage.getItem("key-password");
                if (savedPassword) {
                    this.keyPassword = savedPassword;
                } else {
                    this.keyPassword = prompt("Enter password for private key");
                }
            }
            return this.keyPassword;
        },
        async loadState() {
            const databaseDocument: any = await dbMgr.returnState(DATABASE_HANDLES.auth);
            if (databaseDocument?.user_id) {
                console.log("loaded state => ", databaseDocument);
                this.user_id = databaseDocument.user_id;
                this.machine_id = databaseDocument.machine_id;
                this.known_nodes = databaseDocument.known_nodes;
                await keyManager.importKeyString(databaseDocument.private_key, this.getKeyPassword());
            } else {
                console.log("no user state present...");
            }
        },
        async saveState() {
            const state = {
                user_id: this.user_id,
                machine_id: this.machine_id,
                known_nodes: this.known_nodes,
                private_key: await keyManager.exportKeyString(this.keyPassword),
            };
            await dbMgr.updateUserData(state);
        },
    };

    // next is data view;
    chats: {
        [key: string]: Chat;
    } = {};
    chatsControl = {
        currentChat: "",
        setCurrentChat(chatId: string) {
            this.currentChat = chatId;
        },
        async createChat() {
            // TODO: promts are in UI only;
            const chat_name = prompt("Enter chat name");
            if (chat_name) {
                const chat: Chat = {
                    chat_id: generateUUID(),
                    chat_name,
                    messages: {},
                    messages_count: 0,
                };
                store.chats[chat.chat_id] = chat;
                await this.refreshChats();
            } else {
                alert("Chat name cannot be empty");
            }
        },
        async deleteChat(chat_id: string) {
            store.chats[chat_id].removed = true;
            await this.refreshChats();
        },
        async toggleArchiveChat(chat_id: string, archived: boolean) {
            store.chats[chat_id].archived = archived;
            await this.refreshChats();
        },
        // internal method to save in db state => current state => push;
        async refreshChats() {
            await dbMgr.saveStateChats(store.chats);
            store.chats = ((await dbMgr.returnState("chats")) as any).chats;
            console.log("this.chats", store.chats);
            store.broadcastMessage("chats/push", store.chats);
        },
        async createMessage({ chat_id, text, attachments }: { chat_id: string; text: string; attachments?: any[] }) {
            const message: Message = {
                message_id: generateUUID(),
                created_at: Date.now(),
                text: text,
            };
            if (attachments?.length) {
                message.attachments = attachments.map(attArg => attArg.attachment);
                await Promise.all(
                    attachments.map(async attArg => {
                        await fileStorage.storeFileBrowser(attArg.attachment, attArg.file);
                    })
                );
            }
            store.chats[chat_id].messages[message.message_id] = message;
            store.chats[chat_id].messages_count = Object.keys(store.chats[chat_id].messages).length;

            await dbMgr.saveStateChats(store.chats);
            store.chats = ((await dbMgr.returnState("chats")) as any).chats;
            store.broadcastMessage("chats/push", store.chats);
        },
    };
    // holds current state of attachments for chats ... if they loaded or not;
    attMap: any = {
        loadedFiles: {},
        pendingFiles: {},
    };
    attControl = {
        checkFileStatus(attachment: Attachment) {
            if (store.attMap.pendingFiles[attachment.attachment_id]) {
                return "pending";
            } else if (store.attMap.loadedFiles[attachment.attachment_id]) {
                return "loaded";
            } else {
                return "none";
            }
        },
        async requestFile(attachment: Attachment) {
            // TODO: check if any nodes connected beforehand
            // if less 2 mb download immidiately
            if (attachment.size <= 1024 * 1024 * 2) {
                const file = await new Promise((res, rej) => {
                    store.broadcastMessage("attach/request_entire", attachment);
                    // setTimeout as waiting too long...
                    const requestTimeout = setTimeout(() => {
                        res(null);
                    }, 60 * 1000);
                    const dbPollInterval = setInterval(async () => {
                        const fileLoaded = await fileStorage.checkAttachmentLoaded(attachment);
                        if (fileLoaded) {
                            // res(fileLoaded);
                            const file = await fileStorage.getFileBrowser(attachment);
                            res(file);

                            clearTimeout(requestTimeout);
                            clearInterval(dbPollInterval);
                        }
                    }, 250);
                });
            } else {
                console.warn("file too big to download");
            }
            // small files can be directly loaded;
            // store.attMap.loadedFiles[attachment.attachment_id] = true;
        },
    };

    constructor() {
        console.log("store initialized!");
    }
    async initSavedState() {
        // init database, if empty then create basic, else restore saved;
        await dbMgr.init();
        // try to restore user state if present
        await this.auth.loadState();
        if (this.auth.user_id) {
            console.log("user state present!", this.auth);
            this.initConnections();
        } else {
            console.log("no user state present!", this.auth);
        }

        this.chats = ((await dbMgr.returnState("chats")) as any).chats;

        console.log("state from store updated", this);
    }
    initConnections() {
        connMgr.init().then(() => {
            // allow some time to connect to present nodes;
            setTimeout(() => {
                console.log("connection ok, now will push state...");
                this.broadcastKnownNodes();
                store.broadcastMessage("chats/push", this.chats);
            }, 1000);
        });
    }

    async generateUser(password: string) {
        await this.auth.createNewId(password);
        this.initConnections();
    }
    // TODO: import user also must have the same path;
    async deleteUserLogin() {
        // send all nodes a signal to remove => get acks at least one
        // delete saved password, db entires all and reset everything with full reloyad
        await dbMgr.dropDatabase();
        window.location.replace("/");
    }

    async encryptData(data: any) {
        return keyManager.encryptData(data);
    }
    async decryptData(data: any) {
        return keyManager.decryptData(data);
    }
    async handleMessage(data: any) {
        const message: any = await this.decryptData(data);
        if (!message) {
            console.warn("could not decrypt message =>", message);
            return;
        }
        console.log("handleMessage => ", message);
        if (message.event === "nodes/broadcast") {
            const currentNodes: any = this.auth.known_nodes;
            Object.values(message.document).forEach((node: any) => {
                // if node not exists => add;
                if (!currentNodes[node.machine_id]) {
                    currentNodes[node.machine_id] = node;
                }
                // check if new node value is more recent
                if (currentNodes[node.machine_id].last_update < node.last_update) {
                    currentNodes[node.machine_id] = node;
                }
            });
            this.auth.known_nodes = currentNodes;
            this.auth.saveState();
            connMgr.checkConnectionToOtherNodes();
        }
        if (message.event === "chats/push") {
            const chats = {
                ...this.chats,
                ...message.document,
            };
            await dbMgr.saveStateChats(chats);
            this.chats = ((await dbMgr.returnState("chats")) as any).chats;
        }
        if (message.event === "chats/request_push") {
            store.broadcastMessage("chats/push", this.chats);
        }
        if (message.event === "attach/request_entire") {
            const fileExists = await fileStorage.checkAttachmentLoaded(message.document);
            if (fileExists) {
                const fileBlob: Blob = await fileStorage.getFileBrowser(message.document);
                const buffer = new Uint8Array(await fileBlob.arrayBuffer());
                const fileDocument = {
                    attachment: message.document,
                    buffer,
                };
                store.broadcastMessage("attach/send_entire", fileDocument);
            }
        }
        if (message.event === "attach/send_entire") {
            // TODO: implement receiving file...
            const fileDocument = message.document;
            const file = new File([fileDocument.buffer], fileDocument.attachment.filename, {
                type: fileDocument.attachment.type,
                lastModified: fileDocument.attachment.lastModified,
            });
            await fileStorage.storeFileBrowser(fileDocument.attachment, file);
        }
    }
    async broadcastMessage(event: string, document: any) {
        const data = await this.encryptData({ event, document });
        if (!data) {
            console.error("could not encrypt message =>", data);
            return;
        }
        connMgr.broadcastMessage(data);
    }
    async broadcastKnownNodes() {
        this.broadcastMessage("nodes/broadcast", this.auth.known_nodes);
    }
    requestUpdates() {
        const connectedPeers = connMgr.getConnectedPeeers();
        console.log("connectedPeers", connectedPeers);
        if (connectedPeers.length > 0) {
            this.broadcastMessage("chats/request_push", null);
            return true;
        } else {
            return false;
        }
    }
}
export const store = proxy(new Store());

// watch known_nodes and broadcast on change;
subscribeKey(store.auth, "known_nodes", known_nodes => {
    console.log("known_nodes has changed to", known_nodes);
    if (connMgr.started) {
        store.broadcastKnownNodes();
    }
});
// watch chats
// subscribeKey(store, "chats", chats => {
//     console.log("known_nodes has changed to", chats);
//     if (connMgr.started) {
//         store.broadcastMessage("chats/push", chats);
//     }
// });

// export default store;
export default store;
