interface Node {
    machine_id: string;
    active: boolean;
    device_name: string;
}

export interface TopLevelDatabase {
    _id: string;
    chats: Chat[];
}

export interface Auth {
    user_id: string;
    machine_id: string;
    known_nodes: string[];
}

// chats {} key:chat_id, value:Chat
// chats and messages are deleted my flag.
// chats can also be archived to be put to the bottom of it;
export interface Chat {
    chat_id: string;
    chat_name: string;
    messages: {
        [key: string]: Message;
    };
    messages_count: number;
    archived?: boolean;
    removed?: boolean;
}
export interface Message {
    message_id: string;
    created_at: number;
    modified_at?: number;
    text: string;
    attachments?: Attachment[];
    removed?: boolean;
}

// attachments stored at specific folder and found by id? or use name as is...
// attachments deleted by removing the message and removing attach from there
// later by unlink method to walk on current state and delete anything thats not in current messages;
export interface Attachment {
    attachment_id: string;
    // voice/photo/etc for custom formats;
    attachment_type: string;
    created_at: number;
    name: string;
    // in bytes to determine autoload;
    size: number;
    // mime type technical
    type: string;
    lastModified?: number;
}
export interface AttachmentFile extends Attachment {
    file: File;
}
export interface AttachmentBuffer extends Attachment {
    buffer: Uint8Array;
}
export interface AttachmentBufferPart extends Attachment {}

export interface FileLocal {
    attachment_id: string;
    loaded: boolean; // if file fully loaded locally...
    file: File | Blob | ArrayBuffer; // file as entire, or arraybuffer if its loading now;
    size: number;
}
// stores local state of files, which are loaded which are still loading...
export interface FileQueue {}

// data sent plaintext between nodes
export interface DataMessageExternal {
    format: string;
    // uuid4
    id: string;
    // when message formed
    created_at: number;
    from_machine_id: string;
    // encrypted with private key mgspack
    data: DataMessageEncrypted;
}
export interface DataMessageEncrypted {
    format: string;
    iv: Uint8Array;
    data: Uint8Array;
}
export interface DataMessageInternal {
    // event or command, type of data
    event: string;
    // document from database or smth...
    document?: any;
}

// TODO: rethink it all...
// better to have database => sync it between devices
// like when one comes online we sync it between them and thats it.
// using simple replicate to file back and forth...

// idea => use gundb for peer discovery and connections
// store medatadata about chats and the like in fully encrypted way
// it can user indexed db so probably for files correct... but I also want to store files in my own way so...
