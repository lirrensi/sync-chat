import { Peer, DataConnection } from "peerjs";
import { PEERJS_CONNECTION_PREFIX } from "../constants";
import { generateUUID } from "../helpers/crypto";
import store from "../store";

import { DataMessageEncrypted, DataMessageExternal } from "../types";

// singleton class manager for peer connections;
export class PeerManager {
    started = false;
    connection: Peer | null;
    connMap: {
        [key: string]: DataConnection;
    } = {};

    connectionCheckInterval: any;

    constructor() {
        this.connection = null;
    }
    async init() {
        return new Promise<void>(resolve => {
            const idString = this.idStringOwn;
            this.connection = new Peer(idString);
            this.connection.on("open", () => {
                this.started = true;
                resolve();
                console.log("peer => connection open", this.connection);
                this.connectionCheckInterval = setInterval(() => {
                    this.checkConnectionToOtherNodes();
                }, 10 * 1000);
            });
            this.connection.on("close", () => {
                console.warn("peer => connection close");
            });
            this.connection.on("disconnected", () => {
                console.warn("peer => connection disconnected");
                this.connection.reconnect();
            });
            this.connection.on("error", error => {
                // console.error("peer => OWN connection error", error, this.connection);
                resolve();
            });

            this.connection.on("connection", conn => {
                this.connAttachListeners(conn, conn.metadata.machine_id);
            });
        });
    }
    get idStringOwn() {
        return PEERJS_CONNECTION_PREFIX + store.auth.user_id + "_" + store.auth.machine_id;
    }
    idStringRemote(machine_id: string) {
        return PEERJS_CONNECTION_PREFIX + store.auth.user_id + "_" + machine_id;
    }
    getConnectedPeeers() {
        return Object.values(this.connMap).filter(conn => conn.open);
    }
    connAttachListeners(conn: DataConnection, remote_machine_id: string) {
        conn.on("open", () => {
            console.log("connection open to =>", conn);
            this.connMap[remote_machine_id] = conn;

            conn.on("data", (data: any) => {
                console.log("received data from => ", conn.label, data);
                this.handleMessage(data);
            });
        });
        conn.on("error", error => {
            console.error("peer => remote connection error", error, this.connection);
        });
    }
    createNewConnection(machine_id: string) {
        const idString = this.idStringRemote(machine_id);
        const conn = this.connection.connect(idString, {
            label: store.auth.machine_id,
            metadata: {
                machine_id: store.auth.machine_id,
            },
        });
        this.connAttachListeners(conn, machine_id);
        // attach even listeners;
    }
    // runs on enter, on nodes change, and else...
    checkConnectionToOtherNodes() {
        const myMachineID = store.auth.machine_id;
        const knownNodes = Object.values(store.auth.known_nodes).filter(
            (node: any) => node.active && node.machine_id !== myMachineID
        );

        console.log("checkConnectionToOtherNodes => nodes to connect to: ", knownNodes, this.connMap);
        knownNodes.forEach((node: any) => {
            // if connection present...
            const conn = this.connMap[node.machine_id];
            console.log("checking if connection present to =>", node.machine_id, conn);
            if (!conn) {
                console.log("conn not present => creating new connection to =>", node.machine_id);
                this.createNewConnection(node.machine_id);
            } else {
                if (!conn.open) {
                    console.log("conn not open => opening connection to =>", node.machine_id);
                    conn.close();
                    this.createNewConnection(node.machine_id);
                } else {
                    console.log("connection ok, no need to do anything => ", node.machine_id);
                }
            }
        });
    }
    createMessageWrapper(data: DataMessageEncrypted): DataMessageExternal {
        return {
            format: "external_v1",
            id: generateUUID(),
            created_at: Date.now(),
            from_machine_id: store.auth.machine_id,
            data,
        };
    }
    async handleMessage(message: DataMessageExternal) {
        // TODO: process here if message is not too stale?
        store.handleMessage(message.data);
    }
    broadcastMessage(message: DataMessageEncrypted) {
        const out = this.createMessageWrapper(message);
        for (const conn of Object.values(this.connMap)) {
            if (conn.open) {
                conn.send(out);
            }
        }
    }

    async sendData(data, nodes) {}
    // startConnection() {}

    // createInitializingConnection({ user_id, machine_id }, known_node) {
    //     const idString = PEERJS_CONNECTION_PREFIX + user_id + "--" + machine_id;
    // }
}

// have user and machine id
// first attempting to connect to existing user_id, if have a device online;
// if found => request known nodes and connect to all nodes...
