import PouchDB from "pouchdb";
import { generateUUID } from "../helpers/crypto";

import { DATABASE_NAME_CHATS } from "../constants";
import { Attachment } from "../types";

export const DATABASE_HANDLES = {
    auth: "auth",
    chats: "chats",
    files: "files",
};

// singleton to manage data
export class DatabaseManager {
    db: PouchDB.Database;

    constructor() {
        this.db = new PouchDB("syncnex");
    }
    async createDocumentIfNotExists(handle: string, template: any) {
        try {
            // Check if the document already exists
            await this.db.get(handle);

            // If the document exists, do nothing
            console.log(`${handle} document already exists.`);
        } catch (error: any) {
            if (error.status === 404) {
                // If the document doesn't exist, create it
                await this.db.put(template);
                console.log("top_level document created successfully.");
            } else {
                // Handle other errors
                console.error("Error checking document existence:", error);
            }
        }
    }
    async init() {
        await Promise.all([
            this.createDocumentIfNotExists(DATABASE_HANDLES.auth, {
                _id: DATABASE_HANDLES.auth,
                user_id: "",
                machine_id: "",
                known_nodes: {},
                private_key: "",
            }),
            this.createDocumentIfNotExists(DATABASE_HANDLES.chats, {
                _id: DATABASE_HANDLES.chats,
                chats: {},
            }),
            this.createDocumentIfNotExists(DATABASE_HANDLES.files, {
                _id: DATABASE_HANDLES.files,
            }),
        ]);
    }

    async returnState(handle: string) {
        try {
            const state = await this.db.get(handle);
            console.log("state", state);
            return state;
        } catch (error) {
            console.log("error", error);
            return {};
        }
    }

    async updateUserData(userData: any) {
        let authDocument: any = await this.db.get(DATABASE_HANDLES.auth);
        authDocument = {
            ...authDocument,
            ...userData,
        };
        await this.db.put(authDocument);
        console.log("user data updated successfully.");
    }

    async saveStateChats(chats: any) {
        try {
            const chatsDocument: any = await this.db.get(DATABASE_HANDLES.chats);
            chatsDocument.chats = chats;
            await this.db.put(chatsDocument);
            console.log("chat created successfully.");
        } catch (error) {
            console.error("Error creating chat:", error);
        }
    }

    async dropDatabase() {
        return this.db.destroy();
    }

    // TODO: error handling when cant save file ...
    async dbStoreFile(attachment: Attachment, file: File) {
        try {
            const doc = await this.db.get(DATABASE_HANDLES.files);
            // Now that we have the latest revision, we can call putAttachment
            await this.db.putAttachment(
                DATABASE_HANDLES.files,
                attachment.attachment_id,
                doc._rev,
                file,
                attachment.type
            );
            console.log("file added successfully.");
        } catch (error) {
            console.error("Error creating file:", error, arguments);
        }
    }
    async dbGetFile(attachment: Attachment): Promise<Blob | Buffer | null> {
        try {
            const blob = await this.db.getAttachment(DATABASE_HANDLES.files, attachment.attachment_id);
            console.log("file added successfully.");
            return blob;
        } catch (error) {
            console.error("Error creating file:", error);
            return null;
        }
    }
    async dbCheckFile(attachment: Attachment) {
        try {
            // Fetch only the document metadata without loading the actual document content
            const docMeta = await this.db.get(DATABASE_HANDLES.files, { attachments: false });

            // Check if the attachment exists in the document metadata
            if (docMeta._attachments && docMeta._attachments[attachment.attachment_id]) {
                console.log("Attachment exists in the document.");
                return true;
            } else {
                console.log("Attachment does not exist in the document.");
                return false;
            }
        } catch (error: any) {
            if (error.status === 404) {
                console.log("Document not found.");
            } else {
                console.error("Error checking attachment:", error);
            }
            return false;
        }
    }
}
// export const db = new DatabaseManager();
